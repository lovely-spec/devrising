import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-otp',
  templateUrl: './login-otp.page.html',
  styleUrls: ['./login-otp.page.scss'],
})
export class LoginOtpPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
